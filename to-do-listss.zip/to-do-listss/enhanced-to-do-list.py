import json

class ToDoList:
    def __init__(self):
        self.tasks = []

    def add_task(self):
        task = input("Enter the task: ").strip()
        try:
            priority = int(input("Enter priority (1=High, 2=Medium, 3=Low): "))
            if task and 1 <= priority <= 3:
                self.tasks.append({"task": task, "priority": priority})
                print(f"Task '{task}' added successfully!")
            else:
                raise ValueError
        except ValueError:
            print("Invalid priority! Please enter a number between 1 and 3.")

    def remove_task(self):
        self.view_tasks()
        try:
            task_number = int(input("Enter the task number to remove: "))
            if 1 <= task_number <= len(self.tasks):
                removed_task = self.tasks.pop(task_number - 1)
                print(f"Task '{removed_task['task']}' removed successfully!")
            else:
                raise IndexError
        except (ValueError, IndexError):
            print("Invalid task number! Please try again.")

    def prioritize_task(self):
        self.view_tasks()
        try:
            task_number = int(input("Enter the task number to update priority: "))
            if 1 <= task_number <= len(self.tasks):
                new_priority = int(input("Enter new priority (1=High, 2=Medium, 3=Low): "))
                if 1 <= new_priority <= 3:
                    self.tasks[task_number - 1]["priority"] = new_priority
                    print(f"Priority for task '{self.tasks[task_number - 1]['task']}' updated successfully!")
                else:
                    raise ValueError
            else:
                raise IndexError
        except (ValueError, IndexError):
            print("Invalid input! Please try again.")

    def view_tasks(self):
        if not self.tasks:
            print("No tasks available.")
            return
        print("\nTasks:")
        for idx, task in enumerate(sorted(self.tasks, key=lambda x: x["priority"]), start=1):
            print(f"{idx}. {task['task']} (Priority: {task['priority']})")
        print()

    def save_tasks(self):
        try:
            with open("tasks.json", "w") as file:
                json.dump(self.tasks, file)
            print("Tasks saved successfully!")
        except Exception as e:
            print(f"An error occurred while saving tasks: {e}")

    def load_tasks(self):
        try:
            with open("tasks.json", "r") as file:
                self.tasks = json.load(file)
            print("Tasks loaded successfully!")
        except FileNotFoundError:
            print("No saved tasks found.")
        except Exception as e:
            print(f"An error occurred while loading tasks: {e}")

    def clear_tasks(self):
        confirmation = input("Are you sure you want to clear all tasks? (yes/no): ").strip().lower()
        if confirmation == "yes":
            self.tasks.clear()
            print("All tasks cleared!")
        else:
            print("Operation canceled.")


def menu():
    todo_list = ToDoList()
    while True:
        print("\n--- To-Do List Manager ---")
        print("1. Add Task")
        print("2. Remove Task")
        print("3. Prioritize Task")
        print("4. View Tasks")
        print("5. Save Tasks")
        print("6. Load Tasks")
        print("7. Clear All Tasks")
        print("8. Exit")
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            todo_list.add_task()
        elif choice == "2":
            todo_list.remove_task()
        elif choice == "3":
            todo_list.prioritize_task()
        elif choice == "4":
            todo_list.view_tasks()
        elif choice == "5":
            todo_list.save_tasks()
        elif choice == "6":
            todo_list.load_tasks()
        elif choice == "7":
            todo_list.clear_tasks()
        elif choice == "8":
            print("Exiting the To-Do List Manager. Goodbye!")
            break
        else:
            print("Invalid choice! Please try again.")


if __name__ == "__main__":
    menu()
