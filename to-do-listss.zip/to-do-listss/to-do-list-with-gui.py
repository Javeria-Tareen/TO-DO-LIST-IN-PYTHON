import tkinter as tk
from tkinter import messagebox, simpledialog


class AdvancedToDoListApp:
    def __init__(self, root):
        self.tasks = []

        # Main Window
        self.root = root
        self.root.title("Advanced To-Do List Manager")
        self.root.geometry("450x500")

        # Title
        tk.Label(root, text="To-Do List", font=("Helvetica", 18, "bold")).pack(pady=10)

        # Task List Display
        self.task_listbox = tk.Listbox(root, width=50, height=15)
        self.task_listbox.pack(pady=10)

        # Task Input
        tk.Label(root, text="Task:").pack()
        self.task_entry = tk.Entry(root, width=30)
        self.task_entry.pack(pady=5)

        # Priority Input
        tk.Label(root, text="Priority (1=High, 2=Medium, 3=Low):").pack()
        self.priority_entry = tk.Entry(root, width=10)
        self.priority_entry.pack(pady=5)

        # Buttons
        tk.Button(root, text="Add Task", width=20, command=self.add_task).pack(pady=5)
        tk.Button(root, text="Remove Selected Task", width=20, command=self.remove_selected_task).pack(pady=5)
        tk.Button(root, text="Prioritize Task", width=20, command=self.prioritize_task).pack(pady=5)
        tk.Button(root, text="View Tasks", width=20, command=self.view_tasks).pack(pady=5)

    def add_task(self):
        task = self.task_entry.get().strip()
        try:
            priority = int(self.priority_entry.get().strip())
            if task and 1 <= priority <= 3:
                self.tasks.append({"task": task, "priority": priority})
                self.task_entry.delete(0, tk.END)
                self.priority_entry.delete(0, tk.END)
                self.view_tasks()
                messagebox.showinfo("Success", f"Task '{task}' added!")
            else:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Please enter valid task and priority (1, 2, or 3).")

    def remove_selected_task(self):
        selected_task_index = self.task_listbox.curselection()
        if not selected_task_index:
            messagebox.showerror("Error", "Please select a task to remove.")
            return

        selected_task_text = self.task_listbox.get(selected_task_index)
        task_name = selected_task_text.split(" (")[0]

        self.tasks = [task for task in self.tasks if task["task"] != task_name]
        self.view_tasks()
        messagebox.showinfo("Success", f"Task '{task_name}' removed!")

    def prioritize_task(self):
        selected_task_index = self.task_listbox.curselection()
        if not selected_task_index:
            messagebox.showerror("Error", "Please select a task to prioritize.")
            return

        selected_task_text = self.task_listbox.get(selected_task_index)
        task_name = selected_task_text.split(" (")[0]

        try:
            new_priority = simpledialog.askinteger("Set Priority", f"Set new priority for '{task_name}' (1, 2, or 3):")
            if new_priority in {1, 2, 3}:
                for task in self.tasks:
                    if task["task"] == task_name:
                        task["priority"] = new_priority
                        self.view_tasks()
                        messagebox.showinfo("Success", f"Priority updated for '{task_name}'!")
                        return
            else:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Invalid priority. Please enter 1, 2, or 3.")

    def view_tasks(self):
        self.task_listbox.delete(0, tk.END)
        for task in sorted(self.tasks, key=lambda x: x["priority"]):
            self.task_listbox.insert(tk.END, f"{task['task']} (Priority: {task['priority']})")


# Run the application
if __name__ == "__main__":
    root = tk.Tk()
    app = AdvancedToDoListApp(root)
    root.mainloop()
